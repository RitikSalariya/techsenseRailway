module.exports = {
  darkMode: 'class',
  content: [
    './templates/**/*.html',
    './**/templates/**/*.html',
    './static/**/*.js',
    './store/templates/**/*.html',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}